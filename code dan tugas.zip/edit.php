<?php
    echo $_GET['urut'];